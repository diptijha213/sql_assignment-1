USE [EmpLoginDb]
GO
/****** Object:  UserDefinedFunction [dbo].[FirstCheckInTime]    Script Date: 02-07-2024 20:53:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[FirstCheckInTime] 
(
	-- Add the parameters for the function here
	@EmpId Int,@Log_dt Datetime
)
RETURNS Datetime
AS
BEGIN
	-- Declare the return variable here
	DECLARE @FCheckInTime Datetime

	-- Add the T-SQL statements to compute the return value here
	SELECT Top 1 @FCheckInTime=[ChechIn-CheckOutTime] from Emp_Login_Det where EmpID=@EmpId and Convert(varchar,[ChechIn-CheckOutTime],103) =@Log_dt and lower(Attendance)='in' order by [ChechIn-CheckOutTime] asc

	-- Return the result of the function
	RETURN @FCheckInTime

END
GO
/****** Object:  UserDefinedFunction [dbo].[LastCheckOutTime]    Script Date: 02-07-2024 20:53:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
Create FUNCTION [dbo].[LastCheckOutTime] 
(
	-- Add the parameters for the function here
	@EmpId Int,@Log_dt Datetime
)
RETURNS Datetime
AS
BEGIN
	-- Declare the return variable here
	DECLARE @LCheckInTime Datetime

	-- Add the T-SQL statements to compute the return value here
	SELECT Top 1 @LCheckInTime=[ChechIn-CheckOutTime] from Emp_Login_Det where EmpID=@EmpId and Convert(varchar,[ChechIn-CheckOutTime],103) =@Log_dt and lower(Attendance)='out' order by [ChechIn-CheckOutTime] desc

	-- Return the result of the function
	RETURN @LCheckInTime

END
GO
/****** Object:  UserDefinedFunction [dbo].[TotalOutCount]    Script Date: 02-07-2024 20:53:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
Create FUNCTION [dbo].[TotalOutCount] 
(
	-- Add the parameters for the function here
	@EmpId Int,@Log_dt Datetime
)
RETURNS Int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @TotOutCount Int

	-- Add the T-SQL statements to compute the return value here
	SELECT  @TotOutCount=Count(*) from Emp_Login_Det where EmpID=@EmpId and Convert(varchar,[ChechIn-CheckOutTime],103) =@Log_dt and lower(Attendance)='out'

	-- Return the result of the function
	RETURN @TotOutCount

END
GO
/****** Object:  UserDefinedFunction [dbo].[TotalWorkHours]    Script Date: 02-07-2024 20:53:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[TotalWorkHours] 
(
	-- Add the parameters for the function here
	@EmpId Int,@Log_dt Datetime
)
RETURNS Varchar(5)
AS
BEGIN
	
	

    -- Insert statements for procedure here
	-- Declare the return variable here
	DECLARE @TotWorkHours int=0;
	DECLARE @lg_dt Datetime
	DECLARE @att varchar(3)
	DECLARE @inlg_dt Datetime
	DECLARE @outlg_dt Datetime
	DECLARE @difflg_dt int
	Declare @c int=0;
	Declare @hh int=0;
	Declare @mm int=0;
	Declare @hhs varchar(2);
	Declare @mms varchar(2);

	-- Add the T-SQL statements to compute the return value here
	DECLARE Emp_att CURSOR
	for SELECT  [ChechIn-CheckOutTime],lower(Attendance) from Emp_Login_Det where EmpID=@EmpId and Convert(varchar,[ChechIn-CheckOutTime],103) =@Log_dt order by [ChechIn-CheckOutTime] asc
	OPEN Emp_att;  
	FETCH NEXT FROM Emp_att INTO @lg_dt,@att;
	WHILE @@FETCH_STATUS = 0    
    BEGIN  
		Set @c=@c+1;
		if @att='in'
		begin
			Set @inlg_dt=@lg_dt;
			
		end		
		else
		begin
			Set @outlg_dt=@lg_dt;
			
		end
			
		if @c=2
		begin
			Set @difflg_dt=DATEDIFF(MI,@inlg_dt,@outlg_dt);
			
			Set @c=0;
			Set @TotWorkHours=@TotWorkHours+@difflg_dt;
			
		end

			
        FETCH NEXT FROM Emp_att INTO @lg_dt,@att;    
    END;  
	CLOSE Emp_att; 
	DEALLOCATE Emp_att;  
	if @TotWorkHours>=60
	begin
		Select @hh=@TotWorkHours/60;
		Select @mm=@TotWorkHours%60;
	end
	if @hh<10
		set @hhs='0'+convert(varchar(2),@hh);
	else
		set @hhs=convert(varchar(2),@hh);

	if @mm<10
		set @mms='0'+convert(varchar(2),@mm);
	else
		set @mms=convert(varchar(2),@mm);

	return @hhs+':'+@mms;
END

GO
/****** Object:  Table [dbo].[Emp_Login_Det]    Script Date: 02-07-2024 20:53:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Emp_Login_Det](
	[EmpID] [int] NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[ChechIn-CheckOutTime] [datetime] NOT NULL,
	[Attendance] [varchar](3) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[GetWorkHour]    Script Date: 02-07-2024 20:53:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetWorkHour]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	-- Declare the return variable here
	
	Declare @emp_id int=0;
	Declare @lg_dt varchar(10);
	Declare @Name varchar(50);
	Create table #LogDet
	(
	EmpID int,
	[Name] varchar(50),
	FirstCheckInTime datetime,
	LastCheckOutTime datetime,
	TotalOutCount int,
	TotalWorkHours varchar(50)
	);

	-- Add the T-SQL statements to compute the return value here
	DECLARE Emp_cur CURSOR
	for SELECT  distinct EmpID,Convert(varchar,[ChechIn-CheckOutTime],103),[Name] from Emp_Login_Det  order by 1,2 asc
	OPEN Emp_cur;  
	FETCH NEXT FROM Emp_cur INTO @emp_id,@lg_dt,@Name;
	WHILE @@FETCH_STATUS = 0    
    BEGIN  
		insert into #LogDet
		select @emp_id As EmpID,@Name as [Name],dbo.FirstCheckInTime(@emp_id,@lg_dt) as FirstCheckInTime ,dbo.LastCheckOutTime(@emp_id,@lg_dt) as LastCheckOutTime,dbo.TotalOutCount(@emp_id,@lg_dt) as TotalOutCount,dbo.TotalWorkHours(@emp_id,@lg_dt) as [TotalWorkHours(HH:MM)]	
        FETCH NEXT FROM Emp_cur INTO @emp_id,@lg_dt,@Name;    
    END;  
	CLOSE Emp_cur; 
	DEALLOCATE Emp_cur;  
	
	select * from  #LogDet
END
GO
